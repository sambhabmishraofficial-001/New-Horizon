﻿Lattice for Windows

This is a placeholder installer package.
Replace public/downloads/Lattice-Windows.zip with your signed build.

